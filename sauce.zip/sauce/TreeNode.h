#ifndef TREENODE_H
#define TREENODE_H
#include "Board.h"
#include <vector>
using namespace std;
class TreeNode {
public:
	TreeNode();
	TreeNode(Board*, int, int);

	void add_child(TreeNode*);

	Board* board;
	int parent_color;
	int child_id;
	vector<TreeNode*>children;
};

#endif //TREENODE_H
