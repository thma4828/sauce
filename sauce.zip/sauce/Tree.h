#ifndef TREE_H
#define TREE_H
#include "Node.h"
class Tree
{
public:
	Tree();
	Tree(Node*);
	Node* root;
	Node* curr_move;
	Node* curr_node;

	int calculate_move_white();
};

#endif //TREE_H
