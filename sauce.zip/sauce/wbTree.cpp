#include "wbTree.h"
#include "TreeNode.h"

wbTree::wbTree(){
	//empty constructor
}
wbTree::wbTree(Board* b, int p, int cid) {
	root = new TreeNode();
}
