#ifndef WBTREE_H
#define WBTREE_H
#include "TreeNode.h"
#include "Piece.h"
#include <vector>
#include "Board.h"
using namespace std;


class wbTree
{
public:
	wbTree();
	wbTree(Board*, int, int);
private:
	TreeNode* root;
	vector<int>cid_list;
};
#endif //WBTREE_H
